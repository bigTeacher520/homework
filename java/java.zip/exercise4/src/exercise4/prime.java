package exercise4;

public class prime extends Thread{
		   private Thread t;
		   private int beginInt;
		   private int endInt;
		   
		   public prime( int begin,int end) {
		      this.beginInt=begin;
		      this.endInt=end;
		   }
		   
		   public void run() {
		      System.out.println("Running " +  threadName );
		      try {
		         for(int i = 4; i > 0; i--) {
		            System.out.println("Thread: " + threadName + ", " + i);
		            // ���߳�˯��һ��
		            Thread.sleep(50);
		         }
		      }catch (InterruptedException e) {
		         System.out.println("Thread " +  threadName + " interrupted.");
		      }
		      System.out.println("Thread " +  threadName + " exiting.");
		   }
		   
		   public void start () {
		      System.out.println("Starting " );
		      if (t == null) {
		         t = new Thread (this, threadName);
		         t.start ();
		      }
		   }
		}
