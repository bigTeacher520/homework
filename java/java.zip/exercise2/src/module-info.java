/**
 * 
 */
/**
 * @author lenovo
 *
 */
module MyInteger {
}