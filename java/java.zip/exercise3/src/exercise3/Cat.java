package exercise3;

public class Cat extends Anima {
	 @Override
	 public void greeting() {
	 System.out.println("Meow!");
	 }
	}
