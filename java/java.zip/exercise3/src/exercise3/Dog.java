package exercise3;

public class Dog extends Anima {
	 @Override
	 public void greeting() {
	 System.out.println("Woof!");
	 }

	 public void greeting(Dog another) {
	 System.out.println("Woooooooooof!");
	 }
	}

