package exercise3;

abstract public class Anima {
	 abstract public void greeting();
}